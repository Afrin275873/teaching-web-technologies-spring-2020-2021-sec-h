<?php

	header('location: view/index.html');

?>